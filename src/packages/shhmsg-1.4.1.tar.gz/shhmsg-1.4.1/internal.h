/* $Id: internal.h,v 1.4 2002/03/02 19:37:36 sverrehu Exp $ */
#ifndef INTERNAL_SHHMSG_H
#define INTERNAL_SHHMSG_H

#include <stdio.h>  /* FILE */

/* streams for error messages, verbose messages, and general messages. */
#define MSG_DEFAULT_ERROR_STREAM stderr
#define MSG_DEFAULT_VERBOSE_STREAM stderr
#define MSG_DEFAULT_MESSAGE_STREAM stdout

extern FILE *_msgErrorStream;
extern FILE *_msgVerboseStream;
extern FILE *_msgMessageStream;

#define GET_ERROR_STREAM \
    ((_msgErrorStream == NULL) \
        ? MSG_DEFAULT_ERROR_STREAM \
        : _msgErrorStream)
#define GET_VERBOSE_STREAM \
    ((_msgVerboseStream == NULL) \
        ? MSG_DEFAULT_VERBOSE_STREAM \
        : _msgVerboseStream)
#define GET_MESSAGE_STREAM \
    ((_msgMessageStream == NULL) \
        ? MSG_DEFAULT_MESSAGE_STREAM \
        : _msgMessageStream)

extern int _msgShowNameAlways;

#endif
