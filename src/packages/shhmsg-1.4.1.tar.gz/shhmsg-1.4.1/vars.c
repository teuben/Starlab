/* $Id: vars.c,v 1.4 2002/03/02 19:37:36 sverrehu Exp $ */
/*------------------------------------------------------------------------
 |  FILE            vars.c
 |  MODULE OF       shhmsg - library for displaying messages.
 |
 |  DESCRIPTION     Variables common to most of the source files. These
 |                  are collected in a file of their own, to avoid linking
 |                  in functions not used.
 |
 |  WRITTEN BY      Sverre H. Huseby <shh@thathost.com>
 +----------------------------------------------------------------------*/

#include <stdio.h>

#include "internal.h"
#include "shhmsg.h"

/*-----------------------------------------------------------------------+
|  PUBLIC DATA                                                           |
+-----------------------------------------------------------------------*/

/* Actually, these are not public, as they're supposed to be used
 * internally by this library only. */
FILE *_msgErrorStream = NULL;
FILE *_msgVerboseStream = NULL;
FILE *_msgMessageStream = NULL;
