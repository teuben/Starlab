/* $Id: banner.h,v 1.2 1996/04/01 08:33:17 sverrehu Exp $ */
#ifndef BANNER_H
#define BANNER_H

#define MAX_HEIGHT 15

typedef struct {
    unsigned char ascii;
    char *line[MAX_HEIGHT];
} LetterData;

void setFont(int n); /* must be called before anything else. n=1: default */
int  getLetterHeight(void);
int  getInterCharWidth(void);
int  getLetterWidth(int ascii);
int  getTextWidth(const char *s);
char *getLetterLine(int ascii, int line);

#endif
